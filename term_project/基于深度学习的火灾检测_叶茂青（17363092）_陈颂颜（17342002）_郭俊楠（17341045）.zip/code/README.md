训练代码见`code.ipynb`

检测代码可使用`mydetect.py`

提供了一个示例视频`forest1.avi`可用于检测

`a_93.h5`是训练出来的网络权重

