#!/usr/bin/env python
# coding: utf-8

# In[1]:


import tensorflow as tf
import tensorflow_model_optimization as tfmot
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Activation, Flatten
from tensorflow.keras.layers import Conv2D, AveragePooling2D
import os
import numpy as np
import cv2
from tqdm import tqdm
import random
tf.__version__


# In[2]:


NUM_CLASSES = 3
BATCH_SIZE = 64
TRAIN_DIR = "./FIRE-SMOKE-DATASET/Train"
TEST_DIR = "./FIRE-SMOKE-DATASET/Test"
CATEGORIES = ['Fire', 'Neutral']
image_size = 64


# In[3]:


def create_data(DIR):
    training_data = []
    for category in CATEGORIES:  

        path = os.path.join(DIR,category) 
        class_num = CATEGORIES.index(category)  # get the classification  (0 or a 1). 0=C 1=O

        for img in tqdm(os.listdir(path)):  # iterate over each image
            try:
                img_array = cv2.imread(os.path.join(path,img))  # convert to array
                new_array = cv2.resize(img_array, (image_size, image_size))  # resize to normalize data size
                training_data.append([new_array, class_num])  # add this to our training_data
            except Exception as e:  # in the interest in keeping the output clean...
                pass
              
    return training_data

training_data = create_data(TRAIN_DIR)
test_data = create_data(TEST_DIR)
random.shuffle(training_data)


# In[4]:


def process_data(data):
    X = []
    Y = []
    n = 0

    for features,label in data:
        X.append(features)
        Y.append(label)
        n += 1

    X = np.array(X).reshape(-1, image_size, image_size, 3)
    Y = np.array(Y)
    
    return X, Y, n

X_train, Y_train, total_train = process_data(training_data)
X_test, Y_test, total_val = process_data(test_data)


from tensorflow.keras.preprocessing.image import ImageDataGenerator

train_image_generator = ImageDataGenerator(
    rescale=1./255,
    rotation_range=45,
    horizontal_flip=True,
    width_shift_range=0.1,
    height_shift_range=0.1,
    zoom_range=0.5
    )

validation_image_generator = ImageDataGenerator(rescale=1./255)

train_data_gen = train_image_generator.flow(X_train, Y_train, batch_size = BATCH_SIZE)

val_data_gen = validation_image_generator.flow(X_test, Y_test, batch_size = BATCH_SIZE)

model = Sequential()


model.add(Conv2D(filters=16, kernel_size=(3, 3), activation='relu', input_shape=(image_size,image_size,3)))
model.add(AveragePooling2D())
model.add(Dropout(0.5))

model.add(Conv2D(filters=32, kernel_size=(3, 3), activation='relu'))
model.add(AveragePooling2D())
model.add(Dropout(0.5))

model.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))
model.add(AveragePooling2D())
model.add(Dropout(0.5))

model.add(Flatten())

model.add(Dense(units=256, activation='relu'))
model.add(Dropout(0.2))

model.add(Dense(units=128, activation='relu'))

model.add(Dense(units=2, activation = 'softmax'))


# In[ ]:


model.compile(optimizer=tf.keras.optimizers.Adam(),
              loss='sparse_categorical_crossentropy',
              metrics=['acc'])
callbacks = [
    tf.keras.callbacks.ModelCheckpoint(
        filepath='a_{epoch}.h5',
        # Path where to save the model
        # The two parameters below mean that we will overwrite
        # the current checkpoint if and only if
        # the `val_loss` score has improved.
        save_best_only=True,
        monitor='val_loss',
        verbose=1)
]
history = model.fit_generator(
    train_data_gen,
    steps_per_epoch=total_train // BATCH_SIZE,
    epochs=100,
    validation_data=val_data_gen,
    validation_steps=total_val // BATCH_SIZE,
    callbacks = callbacks
)

